/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arvorescaderno;

/**
 *
 * @author renan
 */
public class Arvores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArvoreB a = new ArvoreB();
        a.Inserir(20, 0);
        a.Inserir(10, 0);
        a.Inserir(30, 0);
        a.Inserir(40, 0);
        a.Inserir(15, 0);
        a.Inserir(35, 0);
        a.Inserir(50, 0);
        a.Inserir(25, 0);
        a.Inserir(9, 0);
        a.Inserir(5, 0);
        a.Inserir(13, 0);
        a.Inserir(21, 0);
        a.Inserir(22, 0);
        a.Inserir(23, 0);
        a.Inserir(26, 0);
        a.Inserir(31, 0);
        a.inOrdem(a.getRaiz());



          ArvoreBPlus b = new ArvoreBPlus();
          b.InsereBPlus(1);
          b.InsereBPlus(4);
          b.InsereBPlus(7);
          b.InsereBPlus(10);
          b.InsereBPlus(17);
          b.InsereBPlus(21);
          b.InsereBPlus(31);
          b.InsereBPlus(25);
          b.InsereBPlus(19);
          b.InsereBPlus(20);
          b.InsereBPlus(28);
          b.InsereBPlus(42);
          b.inOrdem(b.getRaiz());
          

        
    }
    
}
